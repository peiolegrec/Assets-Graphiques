

Thank you for downloading from Desizn Tech.
----------------------------------------------------------------------------------
Feel Free to use it for personal and business purposes.

1. You may not call this as your own.
2. You may not reupload it anywhere.
3. You may not sell this anywhere.
----------------------------------------------------------------------------------

You can download more design related freebies from http://desiznech.info